mean_store.factory('Dashboard_Factory', function($http) {
          var factory = {};
          
          return factory;
        });